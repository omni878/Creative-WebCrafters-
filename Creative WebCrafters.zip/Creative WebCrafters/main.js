// Initialize particles.js
document.addEventListener('DOMContentLoaded', function() {
    particlesJS('particles-js', {
        particles: {
            number: {
                value: 150,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: ['#00ff88', '#00a1ff', '#ff00ff', '#00ffff']
            },
            shape: {
                type: ['circle', 'triangle'],
                stroke: {
                    width: 1,
                    color: '#000000'
                }
            },
            opacity: {
                value: 0.6,
                random: true,
                anim: {
                    enable: true,
                    speed: 1,
                    opacity_min: 0.1,
                    sync: false
                }
            },
            size: {
                value: 4,
                random: true,
                anim: {
                    enable: true,
                    speed: 2,
                    size_min: 0.1,
                    sync: false
                }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: '#00ffff',
                opacity: 0.4,
                width: 1
            },
            move: {
                enable: true,
                speed: 3,
                direction: 'none',
                random: true,
                straight: false,
                out_mode: 'out',
                bounce: false,
                attract: {
                    enable: true,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: 'canvas',
            events: {
                onhover: {
                    enable: true,
                    mode: ['grab', 'bubble']
                },
                onclick: {
                    enable: true,
                    mode: 'push'
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 200,
                    line_linked: {
                        opacity: 0.8
                    }
                },
                bubble: {
                    distance: 200,
                    size: 6,
                    duration: 0.3,
                    opacity: 0.8,
                    speed: 3
                }
            }
        },
        retina_detect: true
    });
});


// Enhanced rolling gallery initialization
document.addEventListener('DOMContentLoaded', function() {
    const galleries = document.querySelectorAll('.rolling-gallery');
    
    galleries.forEach(gallery => {
        const track = gallery.querySelector('.gallery-track');
        const items = track.querySelectorAll('.gallery-item');
        const totalItems = items.length;
        
        // Set initial position
        track.style.setProperty('--total-items', totalItems);
        
        // Clone items for seamless scrolling
        const clonedItems = Array.from(items).map(item => item.cloneNode(true));
        clonedItems.forEach(clone => track.appendChild(clone));
        
        // Calculate animation duration based on number of items
        const animationDuration = totalItems * 4; // 4 seconds per item
        track.style.animation = `scroll ${animationDuration}s linear infinite`;
        
        // Direction based on gallery type
        if (gallery.classList.contains('design-gallery')) {
            track.style.animation = `scroll ${animationDuration}s linear infinite reverse`;
        }
        
        // Pause/Resume animation on hover
        gallery.addEventListener('mouseenter', () => {
            track.style.animationPlayState = 'paused';
        });
        
        gallery.addEventListener('mouseleave', () => {
            track.style.animationPlayState = 'running';
        });
        
        // Reset animation smoothly when it completes
        track.addEventListener('animationend', () => {
            track.style.animation = 'none';
            track.offsetHeight; // Trigger reflow
            track.style.animation = `scroll ${animationDuration}s linear infinite${
                gallery.classList.contains('design-gallery') ? ' reverse' : ''
            }`;
        });
        
        // Handle click events on gallery items
        track.addEventListener('click', (e) => {
            const item = e.target.closest('.gallery-item');
            if (item) {
                const link = item.querySelector('a');
                if (link && !e.target.closest('a')) {
                    // Only trigger click if the clicked element is not the link itself
                    link.click();
                }
            }
        });
    });
});


// Add this to your existing main.js file
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other items
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                }
            });
            
            // Toggle current item
            item.classList.toggle('active');
            
            // Add hover effect on active state
            if (!isActive) {
                item.style.transform = 'translateY(-5px)';
                setTimeout(() => {
                    item.style.transform = 'translateY(0)';
                }, 200);
            }
        });
    });
});


// Contact Form Handling
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = contactForm.querySelector('.submit-btn');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<span class="button-text">Sending...</span>';
            
            try {
                const response = await fetch(contactForm.action, {
                    method: 'POST',
                    body: new FormData(contactForm),
                    headers: {
                        'Accept': 'application/json'
                    }
                });
                
                if (response.ok) {
                    submitBtn.innerHTML = '<span class="button-text">Message Sent!</span> ✓';
                    contactForm.reset();
                    setTimeout(() => {
                        submitBtn.innerHTML = originalText;
                    }, 3000);
                } else {
                    throw new Error('Form submission failed');
                }
            } catch (error) {
                submitBtn.innerHTML = '<span class="button-text">Error! Try Again</span> ✗';
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                }, 3000);
            }
        });
    }
});


// Add this to your existing main.js file
document.addEventListener('DOMContentLoaded', function() {
    // Update copyright year
    const yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});


// Add this to your existing main.js file
document.addEventListener('DOMContentLoaded', function() {
    // Navigation functionality
    const navbar = document.querySelector('.navbar');
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Toggle mobile menu
    navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Update the navigation scroll behavior
    let lastScroll = 0;
    let isScrolling = false;

    window.addEventListener('scroll', () => {
        if (!isScrolling) {
            window.requestAnimationFrame(() => {
                const currentScroll = window.pageYOffset;
                
                // Always show navbar at the top of the page
                if (currentScroll <= 0) {
                    navbar.classList.remove('scroll-down');
                    navbar.classList.remove('scroll-up');
                    isScrolling = false;
                    return;
                }

                // Modified scroll behavior to prevent navbar from completely disappearing
                if (currentScroll > lastScroll && !navbar.classList.contains('scroll-down')) {
                    // Scrolling down
                    navbar.classList.remove('scroll-up');
                    navbar.classList.add('scroll-down');
                } else if (
                    (currentScroll < lastScroll && navbar.classList.contains('scroll-down')) ||
                    currentScroll < 50
                ) {
                    // Scrolling up or near top
                    navbar.classList.remove('scroll-down');
                    navbar.classList.add('scroll-up');
                }

                lastScroll = currentScroll;
                isScrolling = false;
            });
        }
        isScrolling = true;
    });

    // Update smooth scroll behavior for nav links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            // Close mobile menu if open
            const navMenu = document.querySelector('.nav-menu');
            const navToggle = document.querySelector('.nav-toggle');
            navMenu.classList.remove('active');
            navToggle.classList.remove('active');

            // Get target section
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);

            if (targetSection) {
                // Calculate offset with navbar height
                const navHeight = navbar.offsetHeight;
                const targetPosition = targetSection.offsetTop - navHeight;

                // Smooth scroll with navbar visibility maintained
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });

                // Ensure navbar stays visible
                navbar.classList.remove('scroll-down');
                navbar.classList.add('scroll-up');
            }
        });
    });

    // Active link highlighting
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.3
    };

    const observerCallback = (entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                updateActiveLink(id);
            }
        });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    // Observe all sections
    document.querySelectorAll('section[id]').forEach(section => {
        observer.observe(section);
    });

    function updateActiveLink(sectionId) {
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${sectionId}`) {
                link.classList.add('active');
            }
        });
    }
});

let useFirstNumber = true;

function redirectToWhatsApp() {
    // Alternate between two WhatsApp numbers
    const phoneNumber = useFirstNumber ? '919601359842' : '919067600673';
    
    // Create WhatsApp message
    const message = encodeURIComponent("Hi! I'm interested in the ₹4,999 website package.");
    
    // Generate WhatsApp URL
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${message}`;
    
    // Toggle the number for next click
    useFirstNumber = !useFirstNumber;
    
    // Open WhatsApp in a new tab
    window.open(whatsappURL, '_blank');
}

// Optimize gallery performance
document.addEventListener('DOMContentLoaded', function() {
    const galleries = document.querySelectorAll('.rolling-gallery');
    
    galleries.forEach(gallery => {
        const track = gallery.querySelector('.gallery-track');
        
        // Use requestAnimationFrame for smooth animations
        let rafId;
        const animate = () => {
            // ... existing animation logic ...
            rafId = requestAnimationFrame(animate);
        };
        
        // Pause animation when not in viewport
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    rafId = requestAnimationFrame(animate);
                } else {
                    cancelAnimationFrame(rafId);
                }
            });
        }, { threshold: 0.1 });
        
        observer.observe(gallery);
    });
});
